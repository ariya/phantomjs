module.exports = 'subdir/dummy';
