module.exports = 'dir/dummy';
