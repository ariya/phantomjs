module.exports = 'require/dummy';
