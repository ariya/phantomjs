var b = require('./b');
exports.b = b;
