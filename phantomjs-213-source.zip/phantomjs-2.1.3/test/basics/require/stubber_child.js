exports.stubbed = require('stubbed');
