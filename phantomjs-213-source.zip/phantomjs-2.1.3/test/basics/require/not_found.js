exports.requireNonExistent = function() {
    require('./non_existent');
};
