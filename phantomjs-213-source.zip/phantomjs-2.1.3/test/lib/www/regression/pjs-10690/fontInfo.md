WindSong font is free for personal use.
Licensed under GPL v3.
For full licence text, see https://www.gnu.org/licenses/gpl-3.0.en.html
